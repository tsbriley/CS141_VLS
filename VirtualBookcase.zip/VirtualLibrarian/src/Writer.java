import java.io.*;

public class Writer {

    // Create a file method
    public static void createFile() {
        File fileName = new File("Bookcase.txt");
        // Set our Delimiter
        String delimiter = "||";
        try {
            FileWriter fw = new FileWriter(fileName);
            java.io.Writer output = new BufferedWriter(fw);

            // for each book in Main.books
            for (Book book : Main.books){
                // Create a line with each element in string form seperated by our delimiter
                output.write(book.bookName + delimiter + book.bookAuthor + delimiter + book.bookPageCount + delimiter + book.bookProgress + delimiter +  book.bookGenre + delimiter + book.bookRating + "\n");
            }
            output.close();
        } catch (Exception e) {

        }
    }
}
