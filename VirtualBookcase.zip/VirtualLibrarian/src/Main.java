import java.util.*;
public class Main {
    static Scanner keyboard = new Scanner(System.in);
    static String userName;
    //Create our list variable 'books'
    static ArrayList<Book> books;
    static String term;

    public static void main(String[] args) {
        //initialize our arraylist, so we are able to populate it with our book objects.
        books = new ArrayList<>();
        // Read our file "Bookcase.txt" and add books to our array 'books' with the characteristics defined in the file.
        books = Reader.readFile();
        //User Startup
        System.out.println("---------------------------------");
        System.out.println("Welcome to your Virtual Bookcase!");
        System.out.println("---------------------------------");
        System.out.println("Please enter your name");
        //Set userName to userInput
        userName = keyboard.next();
        System.out.println("---------------------------------");
        System.out.println("Hello " + userName + "");
        System.out.println("How may I help you today...");
        System.out.println("---------------------------------");
        //User Startup End

        //Initialize menu method
        menu();
    }


    //Menu method
    public static void menu() {
        Book book = new Book();

        System.out.println("You currently have: " + books.size() + " books!");
        System.out.println("Keep on reading!!");
        System.out.println("---------------------------------");
        
        //Give choice
        System.out.println("\t1. Add a book ");
        System.out.println(" ");

        System.out.println("\t2. Remove a book ");
        System.out.println(" ");

        System.out.println("\t3. Update a book ");
        System.out.println(" ");

        System.out.println(" \t4. Search for a book ");
        System.out.println(" ");

        System.out.println(" \t5. View library ");
        System.out.println(" ");

        System.out.println(" \t6. Close program ");
        System.out.println(" ");

        //take user input
        System.out.print("Enter the number that applies: ");
        System.out.println(" ");

        System.out.println("---------------------------------");

        //Store the users choice in an int
        int choice = keyboard.nextInt();
        keyboard.nextLine();

        //Use the users choice to initialize that section of our system using switch(choice)
        switch (choice) {
            case 1 : {
                System.out.println("You have selected 'Add a book'");       //DONE
                System.out.println("         Loading now...");
                System.out.println("---------------------------------");
                //Set book = a new book
                book = new Book();
                //Call the addBook method which fills our book object with its characteristics.
                book.addBook();
                //Add our book object with the characteristics to our arraylist.
                books.add(book);
                //After its purpose is fulfilled recall the menu method.
                System.out.println("       Type 1 to continue");
                if (keyboard.nextInt() == 1) {
                    System.out.println("---------------------------------");
                }
                menu();
                break;
            }
            case 2 : {
                System.out.println("You have selected 'Remove a book'");   //DONE
                System.out.println("         Loading now...");
                System.out.println("---------------------------------");

                //remove book
                book.removeBook();
                menu();
                break;
            }
            case 3 : {
                System.out.println("You have selected 'Update a book'");
                System.out.println("         Loading now...");
                System.out.println("---------------------------------");
                System.out.println("Please Enter the title of the Book you wish to Update.");
                term = keyboard.nextLine();
                book = searchTitle(term);
                //returns a book
                book.updateBook();
                System.out.println("       Type 1 to continue");
                if (keyboard.nextInt() == 1) {
                    System.out.println("---------------------------------");
                }
                menu();
                break;
            }
            case 4 : {
                System.out.println("You have selected 'Search your BookCase'");    //DONE
                System.out.println("         Loading now...");
                System.out.println("---------------------------------");
                //loop through array of books assigning them to a number you can type and view.
                //Prompt user with question
                System.out.println("How would you like to search today?");

                System.out.println("\t1. Book Title ");
                System.out.println(" ");
                System.out.println("\t2. Author Name ");
                System.out.println(" ");
                System.out.println("\t3. Progress ");
                System.out.println(" ");
                System.out.println("\t4. Genre ");
                System.out.println(" ");
                System.out.println("\t5. Rating ");
                System.out.println(" ");
                choice = keyboard.nextInt();
                switch (choice) {
                    case 1 : {
                        System.out.println("---------------------------------");
                        System.out.println("Please enter the title of the book you would like to search for");
                        keyboard.nextLine();
                        term = keyboard.nextLine();
                        book = searchTitle(term);
                        book.viewBook();
                        break;
                    }
                    case 2 : {
                        System.out.println("---------------------------------");
                        System.out.println("Please enter the Author of the books you would like to search for");
                        keyboard.nextLine();
                        String term = keyboard.nextLine();

                        searchAuthor(term);
                        break;
                    }
                    case 3 : {
                        System.out.println("This feature is a WIP");
                        break;
                    }
                    case 4 : {
                        System.out.println("---------------------------------");
                        System.out.println("Please enter the Genre ('Fiction / Non-Fiction') of the books you would like to search for");
                        term = keyboard.next();
                        searchGenre(term);
                        break;
                    }
                    case 5 : {
                        System.out.println("---------------------------------");
                        System.out.println("Would you like to search for books of a rating and higher, lower, or the same");
                        System.out.println("\t1. Equal");
                        System.out.println("\t2. Higher");
                        System.out.println("\t3. Less Than");
                        int parameter = keyboard.nextInt();
                        System.out.println("What rating would you like to search for");
                        double term = keyboard.nextDouble();
                        searchRating(term,parameter);
                        break;
                    }
                    default : {
                        System.out.println("That is not a valid command...");
                        System.out.println("Please try again...");
                    }
                }

                System.out.println("       Type 1 to continue");
                if (keyboard.nextInt() == 1) {
                    System.out.println("---------------------------------");
                }
                //After its purpose is fulfilled recall the menu method.
                menu();
            }
            case 5 : {
                System.out.println("You have selected 'View Library'");    //DONE
                System.out.println("         Loading now...");
                System.out.println("---------------------------------");
                viewLibrary();
                System.out.println("       Type 1 to continue");
                if (keyboard.nextInt() == 1) {
                    System.out.println("---------------------------------");
                }
                //After its purpose is fulfilled recall the menu method.
                menu();
                break;
            }
            case 6 : {
                System.out.println("You have selected 'Close Program'");    //DONE
                System.out.println("Have a wonderful day " + userName + "!");
                System.out.println("---------------------------------");
                Writer.createFile();
                break;
            }
            default : {
                System.out.println("That is not a valid command...");
                System.out.println("Please try again...");
            }
        } //End of switch system

    }//End of menu Method

    //Search Book Method
    public static Book searchTitle(String term) {
        //For each book in our books array
        for (Book book : books) {
            //Search if the input term matches a book we have stored in our array and then return that book;
            if (book.bookName.equalsIgnoreCase(term)) {
                return book;
            }
        }
        //if it doesn't match return null and reinitialize menu method
        System.out.println("The book you've entered does not match a book in your Bookcase");
        System.out.println("        Please try again");
        System.out.println("---------------------------------");
        menu();

        //If the input does not match return null (change, so it displays an error message and retakes input)
        return null;
    }
    //End of Search Book Method

    public static void viewLibrary() {
        for (Book book : Main.books) {

            book.viewBook();

        }
    }

    public static void searchAuthor(String term) {
        for (Book book : Main.books) {
            if (book.bookAuthor.equalsIgnoreCase(term)) {
                book.viewBook();

            }
        }
    }

    public static void searchGenre(String term) {
        int temp = 0;
        for (Book book : Main.books) {
            if (book.bookGenre.equalsIgnoreCase(term)) {
                book.viewBook();
                temp++;

            }
        }
        if(temp == 0){
            System.out.println("No Books of the Genre");
        }
    }

    public static void searchRating(double term, int parameter) {       //Change so it displays unread vs read books.
        if (parameter == 1) {
            for (Book book : Main.books) {
                if (book.bookRating == (term)) {
                    book.viewBook();

                }
            }
        } else if (parameter == 2) {
            for (Book book : Main.books) {
                if (book.bookRating >= (term)) {
                    book.viewBook();

                }
            }
        } else if (parameter == 3) {

            for (Book book : Main.books) {
                if (book.bookRating <= (term)) {
                    book.viewBook();

                }
            }
        }
    }
}
